// Filename - component/about.js

import React from "react";

function About() {
	return (
		<div>
			<h2>
				hello everyone
			</h2>
			Click Here :
			<a href="https://www.shrishtiprakash.in">
				Click here
			</a>
		</div>
	);
}
export default About;