// Filename - component/contact.js

import React from "react";

function Contact() {
	return (
		<address>
                Contact Us 
			<br />
			GLA University , Mathura
			<br />
			
		</address>
	);
}

export default Contact;