// Filename - component/home.js

import React from "react";

function Home() {
	return <h1>Welcome to the first react app by 
        Shrishti Prakash
    </h1>;
}

export default Home;